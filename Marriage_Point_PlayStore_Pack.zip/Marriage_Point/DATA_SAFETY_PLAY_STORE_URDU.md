# Play Console Data Safety — تیاری

یہ form app کے حقیقی implementation کے مطابق بھریں۔ یہاں دی گئی فہرست صرف planning guide ہے۔

ممکنہ data categories:
- Name / profile information
- Age / city
- Profile photos
- Account authentication information
- User-generated posts
- Chat messages
- Reports / safety information
- Device/push notification identifiers اگر messaging فعال کی جائے

ہر category کے لیے Google Play Console میں درست طور پر بتائیں:
- collected یا shared
- purpose
- required یا optional
- encryption in transit
- deletion request availability

غلط یا فرضی declarations نہ کریں۔
