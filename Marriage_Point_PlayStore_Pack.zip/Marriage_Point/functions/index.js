const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

exports.onLikeCreated = onDocumentCreated("likes/{likeId}", async (event) => {
  const like = event.data.data();
  if (!like?.fromUid || !like?.toUid || like.fromUid === like.toUid) return;

  const reciprocal = await db.collection("likes")
    .where("fromUid", "==", like.toUid)
    .where("toUid", "==", like.fromUid)
    .limit(1)
    .get();

  if (reciprocal.empty) return;

  const ids = [like.fromUid, like.toUid].sort();
  const matchId = `${ids[0]}_${ids[1]}`;

  await db.collection("matches").doc(matchId).set({
    participants: ids,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    status: "active"
  }, { merge: true });
});

// Basic server-side safety flagging.
// This is only a starter layer; production moderation should use a
// dedicated moderation service and human review for serious reports.
exports.moderateMessage = onDocumentCreated(
  "matches/{matchId}/messages/{messageId}",
  async (event) => {
    const ref = event.data.ref;
    const data = event.data.data();
    const text = String(data?.text || "").toLowerCase();

    const risky = [
      "send money", "otp", "password", "bank account",
      "give me your code", "investment"
    ];

    if (risky.some(word => text.includes(word))) {
      await ref.update({ flagged: true, moderationReason: "safety_keyword" });
    }
  }
);
