# Release Commands

Flutter اور Android SDK نصب ہونے کے بعد project directory میں:

```bash
flutter clean
flutter pub get
flutter analyze
flutter test
flutter build appbundle --release
```

AAB عموماً یہاں بنے گی:

`build/app/outputs/bundle/release/app-release.aab`

APK کے لیے:

```bash
flutter build apk --release
```

لیکن Google Play کے لیے production distribution میں AAB استعمال کریں۔

## Firebase
اپنے Firebase project کی اصل `google-services.json` فائل کو:

`android/app/google-services.json`

میں رکھیں۔

## Signing
Production signing کے لیے اپنی محفوظ keystore بنائیں اور passwords source code یا public ZIP میں نہ رکھیں۔
