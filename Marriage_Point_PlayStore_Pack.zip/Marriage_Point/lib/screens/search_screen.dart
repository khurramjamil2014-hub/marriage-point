import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'report_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final service = FirestoreService();
  String city = '';
  String gender = 'All';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(child: TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.location_city),
                  labelText: 'شہر سے تلاش',
                ),
                onChanged: (v) => setState(() => city = v.trim().toLowerCase()),
              )),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: gender,
                items: const [
                  DropdownMenuItem(value: 'All', child: Text('سب')),
                  DropdownMenuItem(value: 'Male', child: Text('مرد')),
                  DropdownMenuItem(value: 'Female', child: Text('خواتین')),
                ],
                onChanged: (v) => setState(() => gender = v ?? 'All'),
              ),
            ],
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: service.visibleProfiles(),
            builder: (_, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs.where((d) {
                if (d.id == service.uid) return false;
                final p = d.data();
                final c = (p['city'] ?? '').toString().toLowerCase();
                final g = p['gender'] ?? '';
                return (city.isEmpty || c.contains(city)) &&
                    (gender == 'All' || g == gender);
              }).toList();

              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (_, i) {
                  final d = docs[i];
                  final p = d.data();
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.person)),
                      title: Text(p['name'] ?? 'پروفائل'),
                      subtitle: Text('${p['age'] ?? ''} سال • ${p['city'] ?? ''}'),
                      trailing: Wrap(
                        children: [
                          IconButton(
                            tooltip: 'پسند',
                            onPressed: () async {
                              await service.likeUser(d.id);
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('پسند محفوظ کر دی گئی۔')),
                                );
                              }
                            },
                            icon: const Icon(Icons.favorite_border),
                          ),
                          PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'report') {
                                Navigator.push(context, MaterialPageRoute(
                                  builder: (_) => ReportScreen(targetType: 'profile', targetId: d.id),
                                ));
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'report', child: Text('رپورٹ')),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
