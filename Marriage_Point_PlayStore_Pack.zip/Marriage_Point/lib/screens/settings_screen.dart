import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool visible = true;
  final service = FirestoreService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پرائیویسی اور سیفٹی')),
      body: ListView(
        children: [
          SwitchListTile(
            value: visible,
            onChanged: (v) async {
              setState(() => visible = v);
              await service.updateProfile({'isVisible': v});
            },
            title: const Text('پروفائل دکھائیں'),
            subtitle: const Text('بند کرنے سے تلاش میں پروفائل نظر نہیں آئے گا۔'),
          ),
          const ListTile(
            leading: Icon(Icons.phone_disabled),
            title: Text('فون نمبر'),
            subtitle: Text('پبلک پروفائل میں ظاہر نہ کریں۔'),
          ),
          const ListTile(
            leading: Icon(Icons.security),
            title: Text('محفوظ چیٹ'),
            subtitle: Text('چیٹ صرف باہمی میچ کے بعد دستیاب ہے۔'),
          ),
          const ListTile(
            leading: Icon(Icons.block),
            title: Text('بلاک اور رپورٹ'),
            subtitle: Text('کسی بھی صارف کو بلاک یا رپورٹ کیا جا سکتا ہے۔'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('لاگ آؤٹ'),
            onTap: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
    );
  }
}
