import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final service = FirestoreService();

  void edit(Map<String, dynamic> p) {
    final name = TextEditingController(text: p['name'] ?? '');
    final city = TextEditingController(text: p['city'] ?? '');
    final bio = TextEditingController(text: p['bio'] ?? '');
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('پروفائل تبدیل کریں'),
      content: SingleChildScrollView(child: Column(children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'نام')),
        TextField(controller: city, decoration: const InputDecoration(labelText: 'شہر')),
        TextField(controller: bio, maxLines: 4, decoration: const InputDecoration(labelText: 'تعارف')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('منسوخ')),
        FilledButton(onPressed: () async {
          await service.updateProfile({'name': name.text, 'city': city.text, 'bio': bio.text});
          if (context.mounted) Navigator.pop(context);
        }, child: const Text('محفوظ')),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: service.myProfile(),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final p = snap.data!.data() as Map<String, dynamic>? ?? {};
        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const CircleAvatar(radius: 50, child: Icon(Icons.person, size: 55)),
            const SizedBox(height: 12),
            Center(child: Text(p['name'] ?? 'نام',
              style: Theme.of(context).textTheme.headlineSmall)),
            Center(child: Text('${p['age'] ?? ''} سال • ${p['city'] ?? ''}')),
            const SizedBox(height: 12),
            Card(child: Padding(padding: const EdgeInsets.all(16),
              child: Text(p['bio']?.toString().isEmpty == false ? p['bio'] : 'اپنا مختصر تعارف شامل کریں۔'))),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => edit(p),
              icon: const Icon(Icons.edit),
              label: const Text('پروفائل ایڈٹ کریں'),
            ),
            const SizedBox(height: 12),
            const Card(
              child: ListTile(
                leading: Icon(Icons.privacy_tip),
                title: Text('Privacy by default'),
                subtitle: Text('فون اور ای میل کو عوامی پروفائل میں شامل نہ کریں۔'),
              ),
            ),
          ],
        );
      },
    );
  }
}
