import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'chat_screen.dart';

class MatchesScreen extends StatelessWidget {
  const MatchesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = FirestoreService();
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: service.myMatches(),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) {
          return const Center(child: Text('ابھی کوئی میچ نہیں ہے۔'));
        }
        return ListView(
          children: snap.data!.docs.map((d) {
            final data = d.data();
            final ids = List<String>.from(data['participants'] ?? []);
            final other = ids.firstWhere((x) => x != service.uid, orElse: () => '');
            return ListTile(
              leading: const CircleAvatar(child: Icon(Icons.favorite)),
              title: Text('میچ: ${other.isEmpty ? 'صارف' : other.substring(0, 6)}'),
              subtitle: const Text('اب محفوظ چیٹ شروع کریں'),
              onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ChatScreen(matchId: d.id))),
            );
          }).toList(),
        );
      },
    );
  }
}
