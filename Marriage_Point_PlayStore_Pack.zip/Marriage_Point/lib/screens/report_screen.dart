import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class ReportScreen extends StatefulWidget {
  final String targetType;
  final String targetId;
  const ReportScreen({super.key, required this.targetType, required this.targetId});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  String reason = 'Harassment';
  final details = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رپورٹ کریں')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: reason,
              items: const [
                DropdownMenuItem(value: 'Harassment', child: Text('ہراسانی')),
                DropdownMenuItem(value: 'Scam', child: Text('فراڈ / جعلی پروفائل')),
                DropdownMenuItem(value: 'Threat', child: Text('دھمکی')),
                DropdownMenuItem(value: 'Inappropriate', child: Text('نامناسب مواد')),
                DropdownMenuItem(value: 'Other', child: Text('دیگر')),
              ],
              onChanged: (v) => setState(() => reason = v ?? reason),
              decoration: const InputDecoration(labelText: 'وجہ'),
            ),
            TextField(
              controller: details,
              maxLines: 5,
              decoration: const InputDecoration(labelText: 'تفصیل'),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () async {
                await FirestoreService().report(
                  targetType: widget.targetType,
                  targetId: widget.targetId,
                  reason: reason,
                  details: details.text,
                );
                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('رپورٹ محفوظ کر دی گئی ہے۔')),
                  );
                }
              },
              child: const Text('رپورٹ جمع کریں'),
            ),
          ],
        ),
      ),
    );
  }
}
