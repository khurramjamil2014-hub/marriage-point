import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'report_screen.dart';

class ChatScreen extends StatefulWidget {
  final String matchId;
  const ChatScreen({super.key, required this.matchId});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final text = TextEditingController();
  final service = FirestoreService();

  Future<void> send() async {
    await service.sendMessage(widget.matchId, text.text);
    text.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('محفوظ چیٹ'),
        actions: [
          IconButton(
            icon: const Icon(Icons.report),
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ReportScreen(targetType: 'match', targetId: widget.matchId),
            )),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: service.messages(widget.matchId),
              builder: (_, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                return ListView(
                  padding: const EdgeInsets.all(12),
                  children: snap.data!.docs.map((d) {
                    final m = d.data();
                    final mine = m['senderUid'] == service.uid;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Text(m['text'] ?? ''),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          SafeArea(
            child: Row(
              children: [
                Expanded(child: TextField(
                  controller: text,
                  decoration: const InputDecoration(
                    hintText: 'پیغام لکھیں...',
                    contentPadding: EdgeInsets.all(12),
                  ),
                )),
                IconButton(onPressed: send, icon: const Icon(Icons.send)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
