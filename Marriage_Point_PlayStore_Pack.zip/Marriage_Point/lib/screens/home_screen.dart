import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';
import 'profile_screen.dart';
import 'search_screen.dart';
import 'matches_screen.dart';
import 'settings_screen.dart';
import 'report_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final service = FirestoreService();

  final pages = const [
    _FeedPage(),
    SearchScreen(),
    MatchesScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marriage Point'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'ہوم'),
          NavigationDestination(icon: Icon(Icons.search), label: 'تلاش'),
          NavigationDestination(icon: Icon(Icons.favorite), label: 'میچ'),
          NavigationDestination(icon: Icon(Icons.person), label: 'پروفائل'),
        ],
      ),
    );
  }
}

class _FeedPage extends StatefulWidget {
  const _FeedPage();
  @override
  State<_FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<_FeedPage> {
  final controller = TextEditingController();
  final service = FirestoreService();

  Future<void> addPost() async {
    await service.createPost(controller.text);
    controller.clear();
    if (mounted) Navigator.pop(context);
  }

  void compose() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 16, right: 16, top: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('نئی پوسٹ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            TextField(controller: controller, maxLines: 4,
                decoration: const InputDecoration(hintText: 'کچھ شیئر کریں...')),
            const SizedBox(height: 10),
            FilledButton(onPressed: addPost, child: const Text('پوسٹ کریں')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: service.posts(),
          builder: (_, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            if (snap.data!.docs.isEmpty) {
              return const Center(child: Text('ابھی کوئی پوسٹ نہیں ہے۔'));
            }
            return ListView(
              padding: const EdgeInsets.all(12),
              children: snap.data!.docs.map((doc) {
                final p = doc.data();
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(p['text'] ?? ''),
                    subtitle: const Text('کمیونٹی پوسٹ'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) {
                        if (v == 'report') {
                          Navigator.push(context, MaterialPageRoute(
                            builder: (_) => ReportScreen(targetType: 'post', targetId: doc.id),
                          ));
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'report', child: Text('رپورٹ کریں')),
                      ],
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
        Positioned(
          right: 18, bottom: 18,
          child: FloatingActionButton(
            onPressed: compose,
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
