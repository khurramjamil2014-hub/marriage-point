import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  final city = TextEditingController();
  final age = TextEditingController();
  bool signup = false;
  bool loading = false;
  String gender = 'Male';

  Future<void> submit() async {
    setState(() => loading = true);
    try {
      final cred = signup
          ? await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: email.text.trim(), password: password.text)
          : await FirebaseAuth.instance.signInWithEmailAndPassword(
              email: email.text.trim(), password: password.text);

      if (signup && cred.user != null) {
        await FirestoreService().createProfile(
          name: name.text,
          gender: gender,
          age: int.tryParse(age.text) ?? 18,
          city: city.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'Login error')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Marriage Point')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Column(
              children: [
                const Icon(Icons.favorite, size: 70),
                const SizedBox(height: 10),
                Text('محفوظ رشتہ، محفوظ رابطہ',
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 25),
                if (signup) ...[
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'نام')),
                  TextField(controller: age, keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'عمر')),
                  DropdownButtonFormField<String>(
                    value: gender,
                    items: const [
                      DropdownMenuItem(value: 'Male', child: Text('مرد')),
                      DropdownMenuItem(value: 'Female', child: Text('خاتون')),
                    ],
                    onChanged: (v) => setState(() => gender = v ?? 'Male'),
                    decoration: const InputDecoration(labelText: 'جنس'),
                  ),
                  TextField(controller: city, decoration: const InputDecoration(labelText: 'شہر')),
                ],
                TextField(controller: email, decoration: const InputDecoration(labelText: 'ای میل')),
                TextField(controller: password, obscureText: true,
                    decoration: const InputDecoration(labelText: 'پاس ورڈ')),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: loading ? null : submit,
                    child: Text(loading ? 'براہِ کرم انتظار کریں' : signup ? 'اکاؤنٹ بنائیں' : 'لاگ اِن'),
                  ),
                ),
                TextButton(
                  onPressed: () => setState(() => signup = !signup),
                  child: Text(signup ? 'پہلے سے اکاؤنٹ ہے؟ لاگ اِن' : 'نیا اکاؤنٹ بنائیں'),
                ),
                const SizedBox(height: 10),
                const Text(
                  'حفاظت: فون نمبر، ای میل اور نجی معلومات پروفائل پر عوامی طور پر ظاہر نہ کریں۔',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
