import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

class FirestoreService {
  final db = FirebaseFirestore.instance;
  final auth = FirebaseAuth.instance;

  String get uid => auth.currentUser!.uid;

  Future<void> createProfile({
    required String name,
    required String gender,
    required int age,
    required String city,
  }) async {
    await db.collection('profiles').doc(uid).set({
      'uid': uid,
      'name': name.trim(),
      'gender': gender,
      'age': age,
      'city': city.trim(),
      'bio': '',
      'photoUrl': '',
      'isVisible': true,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() =>
      db.collection('profiles').doc(uid).snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> visibleProfiles() {
    return db.collection('profiles')
        .where('isVisible', isEqualTo: true)
        .limit(100)
        .snapshots();
  }

  Future<void> updateProfile(Map<String, dynamic> data) =>
      db.collection('profiles').doc(uid).set({
        ...data,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

  Future<void> likeUser(String targetUid) async {
    if (targetUid == uid) return;
    final id = const Uuid().v4();
    await db.collection('likes').doc(id).set({
      'fromUid': uid,
      'toUid': targetUid,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myMatches() {
    return db.collection('matches')
        .where('participants', arrayContains: uid)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> messages(String matchId) {
    return db.collection('matches').doc(matchId)
        .collection('messages')
        .orderBy('createdAt')
        .snapshots();
  }

  Future<void> sendMessage(String matchId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    await db.collection('matches').doc(matchId)
        .collection('messages').add({
      'senderUid': uid,
      'text': clean,
      'createdAt': FieldValue.serverTimestamp(),
      'flagged': false,
    });
  }

  Future<void> blockUser(String otherUid) =>
      db.collection('users').doc(uid).collection('blocks').doc(otherUid).set({
        'createdAt': FieldValue.serverTimestamp(),
      });

  Future<void> unblockUser(String otherUid) =>
      db.collection('users').doc(uid).collection('blocks').doc(otherUid).delete();

  Future<void> report({
    required String targetType,
    required String targetId,
    required String reason,
    String details = '',
  }) async {
    await db.collection('reports').add({
      'reporterUid': uid,
      'targetType': targetType,
      'targetId': targetId,
      'reason': reason,
      'details': details.trim(),
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> createPost(String text) async {
    if (text.trim().isEmpty) return;
    await db.collection('posts').add({
      'authorUid': uid,
      'text': text.trim(),
      'createdAt': FieldValue.serverTimestamp(),
      'reported': false,
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> posts() =>
      db.collection('posts').orderBy('createdAt', descending: true).limit(50).snapshots();
}
