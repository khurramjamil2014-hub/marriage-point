# Marriage Point — مکمل محفوظ Matrimonial App

یہ پراجیکٹ Flutter + Firebase پر مبنی ایک مضبوط MVP/Production-ready architecture scaffold ہے۔

## شامل خصوصیات

- Email/Password Login & Signup
- محفوظ پروفائل اور Biodata
- شہر، عمر اور جنس کے ذریعے بنیادی تلاش
- Like / Mutual Match
- Match کے بعد Real-time Chat
- Community Posts
- Block
- Report
- Privacy settings
- Public profile visibility control
- Admin reports کے لیے Firestore security architecture
- Server-side mutual match creation
- Basic message safety flagging
- Phone/email کو public profile میں نہ رکھنے کا اصول
- Firebase Firestore security rules
- Firebase Storage security rules

## اہم حفاظتی اصول

کوئی بھی آن لائن ایپ 100% نقصان کی ضمانت نہیں دے سکتی۔ اس پراجیکٹ میں risk کم کرنے کے لیے:

1. فون نمبر اور ذاتی رابطہ معلومات public profile میں نہیں رکھیں۔
2. Chat صرف mutual match کے بعد کھولی گئی ہے۔
3. Block اور Report موجود ہیں۔
4. Reports صرف admin role کے لیے readable ہیں۔
5. Firestore rules client کو arbitrary matches بنانے سے روکتی ہیں۔
6. Mutual match server-side Cloud Function بناتی ہے۔
7. مشکوک chat الفاظ server-side flag ہو سکتے ہیں۔
8. Firebase App Check، human moderation، rate limits اور identity verification production میں لازماً شامل کریں۔

## Firebase Setup

1. Firebase Console میں نیا project بنائیں۔
2. Authentication میں Email/Password enable کریں۔
3. Firestore Database بنائیں۔
4. Storage enable کریں۔
5. Android app register کریں اور `google-services.json` کو:
   `android/app/google-services.json`
   میں رکھیں۔
6. iOS کے لیے `GoogleService-Info.plist` شامل کریں۔
7. Flutter dependencies:
   `flutter pub get`
8. Firestore rules کو `firestore.rules` سے deploy کریں۔
9. Storage rules کو `storage.rules` سے deploy کریں۔
10. Cloud Functions کے لیے:
    `cd functions`
    `npm install`
    پھر Firebase CLI سے functions deploy کریں۔

## Admin

Admin access client-side password سے نہیں ہونا چاہیے۔
Firebase Admin SDK سے custom claim `admin: true` صرف trusted administrator کو دیں۔

## Production سے پہلے لازمی کام

- Firebase App Check
- Phone/email verification
- Optional identity verification
- Rate limiting
- Strong image moderation
- Human moderation dashboard
- Abuse escalation workflow
- Secure push notifications
- Audit logs
- Backup/restore plan
- Terms of Service
- Privacy Policy
- Age policy اور مناسب guardian/safety process
- Legal review

## نوٹ

یہ source project مکمل architecture اور بنیادی functionality دیتا ہے، لیکن آپ کے Firebase project کی credentials/configuration یہاں شامل نہیں کی جا سکتیں۔ Firebase project connect کرنے کے بعد app live backend کے ساتھ چل سکے گی۔
