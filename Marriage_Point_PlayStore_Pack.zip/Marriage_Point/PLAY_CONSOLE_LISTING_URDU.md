# Google Play Listing — Marriage Point

## Short Description
محفوظ اور باوقار انداز میں رشتے تلاش کریں، match کریں اور رابطہ کریں۔

## Full Description
Marriage Point ایک matrimonial social platform ہے جہاں صارف اپنا profile اور basic biodata بنا کر مناسب رشتے تلاش کر سکتا ہے۔

### اہم خصوصیات
- محفوظ account login
- matrimonial profile اور biodata
- شہر اور بنیادی filters کے ذریعے تلاش
- پسند اور mutual matching
- match کے بعد chat
- community posts
- block اور report
- privacy controls
- safety-focused moderation architecture

### Safety
Marriage Point میں block/report اور privacy controls شامل کیے گئے ہیں۔ صارفین کو ذاتی مالی معلومات، passwords، OTP یا غیر ضروری حساس معلومات کسی دوسرے شخص کے ساتھ شیئر نہیں کرنی چاہئیں۔

## Support
[اپنا support email]

## Website
[اپنی website]

## Privacy Policy
[اپنی public privacy policy URL]
