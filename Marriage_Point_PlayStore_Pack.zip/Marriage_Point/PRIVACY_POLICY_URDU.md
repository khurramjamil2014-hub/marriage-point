# Marriage Point — Privacy Policy Template

**آخری اپ ڈیٹ:** [تاریخ درج کریں]

Marriage Point ایک matrimonial/social platform ہے۔ ہماری کوشش ہے کہ صارفین کی ذاتی معلومات کو محفوظ رکھا جائے۔

## 1. معلومات
ہم اکاؤنٹ بنانے، پروفائل بنانے، matching، chat اور safety features کے لیے نام، عمر، شہر، پروفائل معلومات، تصاویر اور استعمال سے متعلق ضروری تکنیکی معلومات process کر سکتے ہیں۔

## 2. حساس رابطہ معلومات
فون نمبر، password اور authentication credentials کو public matrimonial profile میں ظاہر نہیں کیا جانا چاہیے۔

## 3. Chat
Chat صرف متعلقہ match کے context میں دستیاب ہو۔ Safety reports کی صورت میں متعلقہ مواد moderation کے لیے process کیا جا سکتا ہے۔

## 4. Block اور Report
صارف کسی دوسرے صارف کو block یا report کر سکتا ہے۔ Reports safety اور moderation کے لیے استعمال ہوتی ہیں۔

## 5. Firebase
یہ app Firebase Authentication، Firestore، Storage اور Cloud Functions جیسی services استعمال کر سکتی ہے۔ ان services کے استعمال کی تفصیل اپنی final privacy policy میں درست طور پر درج کریں۔

## 6. Data Security
ہم مناسب technical اور organizational safeguards استعمال کرنے کی کوشش کرتے ہیں، لیکن کوئی online service مکمل طور پر risk-free نہیں ہوتی۔

## 7. Data Deletion
صارف account/data deletion کے لیے [اپنا support email] سے رابطہ کر سکتا ہے۔ Production app میں in-app deletion flow بھی شامل کریں۔

## 8. Contact
Support: [اپنا support email]

**اہم:** یہ template ہے۔ Google Play submission سے پہلے اپنے حقیقی data flows، کمپنی/مالک کی معلومات، retention periods اور applicable law کے مطابق اسے legal review کروائیں۔
