# Marriage Point — Terms of Service Template

Marriage Point کو استعمال کرتے ہوئے صارف اتفاق کرتا ہے کہ:

1. غلط شناخت، فراڈ یا دھوکا دہی نہیں کرے گا۔
2. دھمکی، ہراسانی، بلیک میلنگ یا غیر قانونی مواد استعمال نہیں کرے گا۔
3. کسی سے OTP، password، bank PIN یا مالی معلومات طلب نہیں کرے گا۔
4. دوسرے صارف کی ذاتی معلومات اس کی اجازت کے بغیر شیئر نہیں کرے گا۔
5. غلط یا malicious reports کا غلط استعمال نہیں کرے گا۔
6. Marriage Point کسی رشتے یا صارف کی identity کی مکمل ضمانت نہیں دیتا۔
7. Safety concern کی صورت میں Block/Report استعمال کیا جائے۔
8. سنگین یا فوری خطرے کی صورت میں مقامی emergency/law-enforcement services سے رابطہ کیا جائے۔

[اپنی کمپنی/مالک، jurisdiction اور support information شامل کریں۔]
