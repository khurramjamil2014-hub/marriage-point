# Marriage Point — Google Play Store چیک لسٹ

## App Information
- App name: Marriage Point
- Package ID تجویز: `com.marriagepoint.app`
- Version: 1.0.0+1
- Category: Social / Dating
- Target audience: بالغ صارفین کے لیے matrimonial service
- Primary language: Urdu / English

## Release
Google Play پر نئے Android apps کے لیے عموماً `.aab` (Android App Bundle) استعمال کریں، صرف APK نہیں۔

Release سے پہلے:
1. Firebase production project connect کریں۔
2. `google-services.json` شامل کریں۔
3. اپنی unique Android package/application ID مقرر کریں۔
4. Production signing key بنائیں اور محفوظ جگہ پر backup رکھیں۔
5. `flutter pub get` چلائیں۔
6. `flutter analyze` اور tests چلائیں۔
7. `flutter build appbundle --release` چلائیں۔
8. حاصل ہونے والی AAB کو Google Play Console میں upload کریں۔

## بہت اہم
Signing keystore اور passwords کسی کے ساتھ share نہ کریں۔
Google Play Console میں Play App Signing استعمال کرنا بہتر ہے۔

## Privacy
Privacy Policy میں واضح کریں:
- کون سا data collect ہوتا ہے
- profile/photo/chat data کیسے استعمال ہوتا ہے
- report/block کیسے کام کرتا ہے
- data deletion کیسے مانگی جا سکتی ہے
- third-party services (Firebase وغیرہ) کون سی ہیں

## Safety
Play Store submission سے پہلے:
- Report
- Block
- Abuse handling
- Privacy controls
- Account deletion
- Terms of Service
- Privacy Policy
- Contact/support email
ضرور مکمل کریں۔

## Firebase Production Checklist
- Authentication enabled
- Firestore rules deployed
- Storage rules deployed
- Cloud Functions deployed
- App Check enabled
- Admin custom claims configured
- Backups configured
- Monitoring enabled

## Account deletion
Production launch سے پہلے in-app account deletion flow شامل کریں تاکہ صارف اپنا account اور متعلقہ data delete کرنے کی درخواست کر سکے۔
